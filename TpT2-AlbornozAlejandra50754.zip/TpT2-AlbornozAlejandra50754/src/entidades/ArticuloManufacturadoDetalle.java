package entidades;
import lombok.*;
@Getter@Setter@Builder@ToString
public class ArticuloManufacturadoDetalle {
    private Long id;
    private Integer cantidad;
    private ArticuloInsumo insumo;

}
