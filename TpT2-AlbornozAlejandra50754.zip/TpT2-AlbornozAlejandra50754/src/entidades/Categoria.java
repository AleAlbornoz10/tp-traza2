package entidades;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@Builder
public class Categoria {
    private Long id;
    private String denominacion;

    @Builder.Default
    private Set<Articulo> articulos = new HashSet<>();
}
